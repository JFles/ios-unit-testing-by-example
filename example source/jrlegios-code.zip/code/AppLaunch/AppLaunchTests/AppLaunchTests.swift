import XCTest

class AppLaunchTests: XCTestCase {
    func test_emptyJustSoWeHaveAPassingTest() {
    }
}
