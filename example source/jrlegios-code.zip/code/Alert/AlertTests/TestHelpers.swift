import UIKit

func tap(_ button: UIButton) {
    button.sendActions(for: .touchUpInside)
}
