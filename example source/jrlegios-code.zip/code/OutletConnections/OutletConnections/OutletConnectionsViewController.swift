import UIKit

class OutletConnectionsViewController: UIViewController {
    #if false
    @IBOutlet private var label: UILabel!
    @IBOutlet private var button: UIButton!
    #endif

    @IBOutlet private(set) var label: UILabel!
    @IBOutlet private(set) var button: UIButton!
}
