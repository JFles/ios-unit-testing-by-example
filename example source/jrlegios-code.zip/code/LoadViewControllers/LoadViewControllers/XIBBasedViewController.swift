import UIKit

class XIBBasedViewController: UIViewController {
    @IBOutlet var label: UILabel!
}
