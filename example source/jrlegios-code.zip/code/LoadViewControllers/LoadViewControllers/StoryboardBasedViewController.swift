import UIKit

class StoryboardBasedViewController: UIViewController {
    @IBOutlet var label: UILabel!
}
